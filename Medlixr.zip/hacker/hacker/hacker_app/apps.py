from django.apps import AppConfig


class HackerAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'hacker_app'
