from django.shortcuts import render, redirect
from django.views import View
from django.contrib.auth.hashers import make_password
from hacker_app.models import *
from django.contrib.auth import authenticate,login,logout
from .models import *
from django.contrib import messages

class LoginView(View):
    def get(self, request):
        return render(request, "login.html")
    
    def post(self, request):
        params = request.POST
        print(params)
        user = authenticate(email=params["email"], password=params["password"])
        if user is not None and user.user_type == "Doctor":
            login(request,user)
            return redirect("d-dashboard")
        elif user is not None and user.user_type == "patient":
            login(request,user)
            return redirect("p-dashboard")
        elif user is not None and user.user_type == "organization":
            login(request,user)
            return redirect("o-dashboard")
        else:
            return redirect("login")
    




    

class SignupView(View):
    def get(self, request):
        return render(request, "signup.html")
    
    def post(self, request):
        full_name = request.POST.get("first_name")
        email = request.POST.get("email")
        password = request.POST.get("password")
        hashed_password = make_password(password)
        if MyUser.objects.filter(email=email).exists():
            return redirect("signup")
        MyUser(first_name=full_name, email=email, password=hashed_password,is_superuser=True,is_staff=True, is_active=True, user_type="patient").save()
        return redirect("p-dashboard")
    


class DoctorDashboardView(View):
    def get(self, request):
        return render(request, "d-dashboard.html",{"data":StaticData.objects.all})
    def post(self, request):
        try:
            if request.method == 'POST':
                name = request.POST.get('name')
                dis = request.POST.get('dis')
                user_id = 8
                obj = StaticData.objects.create(name=name, dis=dis, user_id=user_id).save()
            messages.success(request, "Your information is added successfully.")
            return redirect("d-dashboard")
        except KeyError:
            return redirect("d-dashboard")
    


class PatientDashboardView(View):
    def get(self, request):
        return render(request, "p-dashboard.html", {"data":StaticData.objects.all})
    



class OrganizationtDashboardView(View):
    def get(self, request):
        return render(request, "o-dashboard.html")
    



class GraphPage(View):
    def get(self, request):
        return render(request, "graph.html")