from django.contrib.auth.models import BaseUserManager, AbstractBaseUser
from django.db import models
import uuid
import random


class CommonTimePicker(models.Model):
    created_at = models.DateTimeField("Created Date", auto_now_add=True)
    updated_at = models.DateTimeField("Updated Date", auto_now=True)

    class Meta:
        abstract = True


class MyUserManager(BaseUserManager):

    def create_user(self, email, password):
        if not email:
            raise ValueError('Users must have an Email Address')

        user = self.model(
            email=self.normalize_email(email),
            is_active=False,
        )
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password):
        user = self.model(email=email)
        user.set_password(password)
        user.is_superuser = True
        if user.is_superuser:
            user.first_name = "Admin"
        user.is_active = True
        user.is_staff = True
        user.save(using=self._db)
        return user
    

USERTYPE = (
    ("Doctor", "Doctor"),
    ("patient", "patient"),
    ("organization", "organization"),
)


class MyUser(AbstractBaseUser, CommonTimePicker):
    user_type = models.CharField("User Type", max_length=20, default='Admin', choices=USERTYPE)
    uuid = models.UUIDField(default=uuid.uuid4, editable=False)
    email = models.EmailField("Email Address", null=True, blank=True, unique=True)
    first_name = models.CharField("First Name", max_length=256, blank=True, null=True)
    last_name = models.CharField("Last Name", max_length=256, blank=True, null=True)
    avatar = models.ImageField("profile photo", null=True, blank=True,upload_to='user_images')
    gender = models.CharField("Gender", max_length=256, blank=True)
    age = models.DateField("Age", blank=True, null= True)
    is_superuser = models.BooleanField("Super User", default=False)
    is_staff = models.BooleanField("Staff", default=False)
    is_active = models.BooleanField("Active", default=False)
    description = models.TextField("Description", max_length=200, null=True, blank=True)
    
    objects = MyUserManager()
    USERNAME_FIELD = 'email'

    def __str__(self):
        return f"{self.uuid}_{self.email}" 
    
    def has_perm(self, perm, obj=None):
        return self.is_staff

    def has_module_perms(self, app_label):
        return self.is_superuser

    def get_short_name(self):
        return self.email




class StaticData(CommonTimePicker):
    user = models.ForeignKey(MyUser, on_delete=models.CASCADE, related_name="user")
    title = models.CharField(max_length=256, blank=True, null=True)
    dis = models.CharField(max_length=256, blank=True, null=True)
    heigth = models.CharField(max_length=256, blank=True, null=True)
    weight = models.ImageField(blank=True, null=True)
    name = models.CharField(max_length=256, blank=True, null=True)

    def __str__(self):
        return self.name