from django.contrib import admin
from hacker_app.models import *


admin.site.register(MyUser)
admin.site.register(StaticData)
