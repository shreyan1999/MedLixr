
from django.urls import path
from .views import *

urlpatterns = [
    path("",LoginView.as_view(),name="login"),
    path("signup/",SignupView.as_view(),name="signup"),
    path("doctor-dashboard/",DoctorDashboardView.as_view(),name="d-dashboard"),
    path("patient-dashboard/",PatientDashboardView.as_view(),name="p-dashboard"),
    path("organization-dashboard/",OrganizationtDashboardView.as_view(),name="o-dashboard"),
    path("graph/",GraphPage.as_view(),name="graph"),
]
