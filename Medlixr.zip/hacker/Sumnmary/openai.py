import openai
import os
import pinecone
from sentence_transformers import SentenceTransformer,util
import requests
#Key- "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"
def create_prompt(query,context):
    prompt="Give the answer for the query from the given context. \
    Query and context are related to Patient's Medical Health record.\
    Query is given in triple backticks and context starts and ends from '####' \
    #### \
    """ + context +"""
    #### \
     ''' """ +query + """'''"""
    
    return prompt

def generate_answer(prompt):
    openai.api_key = os.getenv("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")
    response=openai.Completion.create(
        model="text-davinci-003",
        prompt=prompt,
        max_tokens=7,
        temperature=0
        )
    return (response.choices[0].text).strip()

def find_match(query,k):
    pinecone.init(api_key="",environment="")
    index=pinecone.Index("")
    model=SentenceTransformer('all-MiniLM-L12-v2')
    query_em=model.encode(query).tolist()
    result=index.query(query_em,top_k=k,includeMetadata=True)