# Blockchain
Simple Blockchain using Python on Flask (addblock/mine_block/validate) & hashlib algo sha256

## Flask Routes

1. /mine_block - mining new block
2. /get_chain - display blockchain in json format
3. /valid - Check validity of blockchain

It's just a educational example how you can create simple Blockchain using Python, it can be easily scaled up or be upgraded.
The code is well-documented & easy to read, check it out. If you want to build some advanced features, or scate it up in some commercial project, text me.
